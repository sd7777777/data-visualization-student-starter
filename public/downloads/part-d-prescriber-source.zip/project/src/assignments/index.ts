export interface AssignmentEntry {
  id: string;
  name: string;
  navLabel: string;
  path:
    | '/'
    | '/#data'
    | '/#week-3'
    | '/#week-4'
    | '/#week-5'
    | '/#week-6'
    | '/#week-8'
    | '/week-7'
    | '/week-10'
    | '/week-11'
    | '/week-12';
  sourceDirectory: string;
}

export const assignments: AssignmentEntry[] = [
  {
    id: 'week-12',
    name: 'Try VizHub — Brand vs. generic cost per claim',
    navLabel: 'Cost per claim',
    path: '/week-12',
    sourceDirectory: 'src/assignments/week-12',
  },
  {
    id: 'week-11',
    name: 'Iterate your Project — Regional lens, rebuilt from feedback',
    navLabel: 'Regional lens',
    path: '/week-11',
    sourceDirectory: 'src/assignments/week-11',
  },
  {
    id: 'week-10',
    name: 'Add a New Interaction — Regional lens',
    navLabel: 'Regional lens (Week 10)',
    path: '/week-10',
    sourceDirectory: 'src/assignments/week-10',
  },
  {
    id: 'week-08',
    name: 'Iterate your Project — Brand and generic drugs',
    navLabel: 'Brand & generic',
    path: '/#week-8',
    sourceDirectory: 'src/assignments/week-08',
  },
  {
    id: 'week-07',
    name: 'Recreate an Inspirational Piece — Trillion Atlas',
    navLabel: 'Trillion Atlas',
    path: '/week-7',
    sourceDirectory: 'src/assignments/week-07',
  },
  {
    id: 'week-01',
    name: 'Repository Setup / Prescriber Explorer',
    navLabel: 'Explorer',
    path: '/',
    sourceDirectory: 'src/assignments/week-01',
  },
  {
    id: 'week-02',
    name: 'Load & Summarize a Dataset',
    navLabel: 'Data',
    path: '/#data',
    sourceDirectory: 'src/assignments/week-02',
  },
  {
    id: 'week-03',
    name: 'First Visual',
    navLabel: 'First visual',
    path: '/#week-3',
    sourceDirectory: 'src/assignments/week-03',
  },
  {
    id: 'week-04',
    name: 'Legibility and Validation',
    navLabel: 'Revision',
    path: '/#week-4',
    sourceDirectory: 'src/assignments/week-04',
  },
  {
    id: 'week-05',
    name: 'Interaction and Updated Sketches',
    navLabel: 'Interaction',
    path: '/#week-5',
    sourceDirectory: 'src/assignments/week-05',
  },
  {
    id: 'week-06',
    name: 'Project V1',
    navLabel: 'Project V1',
    path: '/#week-6',
    sourceDirectory: 'src/assignments/week-06',
  },
];

export const assignmentsMap = new Map(
  assignments.map((assignment) => [assignment.id, assignment]),
);
export const defaultAssignment = 'week-01';
